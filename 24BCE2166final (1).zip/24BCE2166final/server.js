const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));

let registrations = [];
let orders = [];
let events = [
  { id: 1, name: "Tech Fest 2026", date: "March 15, 2026" },
  { id: 2, name: "Startup Summit", date: "April 10, 2026" }
];

// 1️⃣ Event Registration Processing
app.post("/register", (req, res) => {
  const { name, email, event } = req.body;
  registrations.push({ name, email, event });
  res.send("Registration Successful!");
});

// 2️⃣ Merchandise Order Processing
app.post("/order", (req, res) => {
  const { item, quantity } = req.body;
  orders.push({ item, quantity });
  res.send("Order Placed Successfully!");
});

// 3️⃣ Admin Event Management
app.post("/addEvent", (req, res) => {
  const { name, date } = req.body;
  events.push({ id: events.length + 1, name, date });
  res.send("Event Added Successfully!");
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
